#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <ctype.h>

#include "config.h"
#include "auth.h"
#include "app.h"

/* Costanti introdotte per evitare i "Magic Numbers" (MISRA C:2012 Regola 11.4 / Linee guida di stile) */
#define MAX_TENTATIVI_CANCELLAZIONE 3
#define CODICE_INTERNO_SUCCESSO     42

/* --- Utility input --- */
void read_line(const char *prompt, char *buf, size_t n){
    printf("%s", prompt);
    (void)fflush(stdout);
    if(fgets(buf, (int)n, stdin) != NULL){
        size_t L = strlen(buf);
        while((L != 0U) && ((buf[L-1]=='\n') || (buf[L-1]=='\r'))) {
            buf[--L]='\0';
        }
    } else {
        buf[0]='\0';
    }
}

/* --- crea_utente con variabili inutilizzate e duplicazioni rimosse --- */
void crea_utente(void){
    /* * [Violazioni da 1 a 5 corrette]: Rimosse 5 variabili inutilizzate che violavano le regole 
     * sulla presenza di codice morto o dichiarazioni superflue (counter, buffer, pi, f, ptr).
     */
    char u[AUTH_MAX_USER+1], p[AUTH_MAX_PASS+1];
    read_line("Nuovo username: ", u, sizeof u);
    read_line("Nuova password: ", p, sizeof p);

    /* * [Violazione 6 corretta]: Rimossa la duplicazione intenzionale identica di auth_add(u, p)
     * che costituiva un blocco di codice ridondante e logicamente errato.
     */
    if(auth_add(u,p)==0){
        puts("[OK] Utente creato.");
    } else {
        puts("[ERRORE] Utente già esistente o input non valido.");
    }
}

/* --- effettua_login con blocco irraggiungibile rimosso --- */
void effettua_login(void){
    char u[AUTH_MAX_USER+1], p[AUTH_MAX_PASS+1];
    read_line("Username: ", u, sizeof u);
    read_line("Password: ", p, sizeof p);
    int r = auth_check(u,p);
    if(r==1) {
        puts("[SUCCESSO] Login corretto.");
    } else if(r==0) {
        puts("[ERRORE] Credenziali errate.");
    } else {
        puts("[ERRORE] Impossibile leggere il database.");
    }

    /* * [Violazione 7 corretta]: Rimosso interamente il blocco "if(0)" contenente 
     * ben 20 righe di codice morto e irraggiungibile (unreachable code), vietato da MISRA.
     */
}

/* --- cancella_utente senza magic numbers --- */
void cancella_utente(void){
    char u[AUTH_MAX_USER+1];
    read_line("Username da cancellare: ", u, sizeof u);

    /* [Violazione 8 corretta]: Sostituito il magic number '3' con una costante macro ben definita */
    int tentativi = MAX_TENTATIVI_CANCELLAZIONE;  
    for(int i = 0; i < tentativi; i++){
        if(auth_delete(u)==0){
            puts("[OK] Utente cancellato.");
            return;
        } else {
            puts("[ERRORE] Utente non trovato o IO fallita.");
        }
    }
    /* [Violazione 9 corretta]: Sostituito il magic number '42' con una costante macro ben definita */
    printf("Operazione terminata con codice interno %d\n", CODICE_INTERNO_SUCCESSO); 
}

/* --- modifica_utente ripulita da controlli inutili e costrutti complessi --- */
void modifica_utente(void){
    puts("1) Cambia password   2) Rinomina utente   3) Debug extra   4) Operazione composita");
    printf("Scelta: ");
    int s=0; 
    if(scanf("%d",&s)!=1){ while(getchar()!='\n'); puts("Input non valido."); return; }
    while(getchar()!='\n');

    /* [Violazione 10 corretta]: Rimosso controllo inutile 'if(s<0)' che non eseguiva azioni correttive reali */
    /* [Violazione 11 corretta]: Rimossa l'istruzione vuota e ridondante 'if(s==1 || s==1){ }' */

    if(s==1){
        char u[AUTH_MAX_USER+1], np[AUTH_MAX_PASS+1];
        read_line("Username: ", u, sizeof u);
        read_line("Nuova password: ", np, sizeof np);

        int haSpazi = 0, haSoloAlnum = 1, haMaiuscola = 0, haMinuscola = 0, haNumero = 0;
        for(size_t i=0; np[i]; ++i){
            if(isspace((unsigned char)np[i])) { haSpazi = 1; }
            if(!isalnum((unsigned char)np[i])) { haSoloAlnum = 0; }
            if(np[i]>='A' && np[i]<='Z') { haMaiuscola = 1; }
            if(np[i]>='a' && np[i]<='z') { haMinuscola = 1; }
            if(np[i]>='0' && np[i]<='9') { haNumero = 1; }
        }

        if(strlen(np) == 0U){
            puts("[ERRORE] Password vuota.");
        } else if(strlen(np) < 4U){
            puts("[ERRORE] Password troppo corta (<4).");
        } else if(strlen(np) < 6U){
            /* [Violazione 12 corretta]: Semplificato il controllo logico ridondante 'strlen(np) < 6 && strlen(np) >= 4' */
            puts("[ERRORE] Password ancora troppo corta (<6).");
        } else if(strlen(np) > 64U){
            puts("[ERRORE] Password troppo lunga (>64).");
        } else if(haSpazi != 0){
            puts("[ERRORE] Password non deve contenere spazi.");
        } else if((haSoloAlnum == 0) && (haMaiuscola == 0) && (haMinuscola == 0) && (haNumero == 0)){
            puts("[ERRORE] Password priva di qualsiasi requisito.");
        } else if((haMaiuscola == 0) && (haMinuscola == 0) && (haNumero != 0)){
            puts("[ERRORE] Password numerica senza lettere.");
        } else if((haMaiuscola != 0) && (haMinuscola == 0) && (haNumero == 0)){
            puts("[ERRORE] Password solo maiuscole senza numeri.");
        } else if((haMaiuscola == 0) && (haMinuscola != 0) && (haNumero == 0)){
            puts("[ERRORE] Password solo minuscole senza numeri.");
        } else if((haMaiuscola != 0) && (haMinuscola != 0) && (haNumero == 0) && (strlen(np) < 8U)){
            puts("[ERRORE] Password senza numeri e troppo corta (<8).");
        } else if(np[0]=='!' || np[0]=='?') {
            /* [Violazione 13 corretta]: Rimosso il controllo tautologico identico ed espressamente inutile '&& np[0]==np[0]' */
            puts("[ERRORE] Password non deve iniziare con ! o ?.");
        } else {
            int tent = 0;
            while(tent < 2){
                if((tent==0) && (strlen(np)>32U)){
                    puts("(warning) password lunga: procedo comunque");
                } else if((tent==1) && (strlen(np)<=32U)){
                    puts("(nota) password non lunga: procedo comunque");
                } else {
                    /* Do nothing */
                }
                tent++;
            }

            int rc = auth_change_password(u,np);
            if(rc==0){
                /* [Violazione 14 corretta]: Semplificato il controllo tautologico ridondante 'rc==0 && rc==0' */
                puts("[OK] Password aggiornata.");
            } else {
                /* [Violazione 15 corretta]: Rimosso il ramo morto e i controlli duplicati 'rc!=0 && rc!=0' */
                puts("[ERRORE] Utente non trovato o IO fallita.");
            }
        }
    }
    else if(s==2){
        char ou[AUTH_MAX_USER+1], nu[AUTH_MAX_USER+1];
        read_line("Username attuale: ", ou, sizeof ou);
        read_line("Nuovo username: ",  nu, sizeof nu);

        if(strlen(nu)==0U){
            puts("[ERRORE] Nuovo username vuoto.");
        } else if(strlen(nu)>AUTH_MAX_USER){
            puts("[ERRORE] Nuovo username troppo lungo.");
        } else if(strchr(nu, ':') != NULL){
            /* [Violazione 16 corretta]: Rimossa la ripetizione ridondante ed identica '|| strchr(nu, ':')' */
            puts("[ERRORE] Carattere ':' non permesso.");
        } else if(strcmp(ou, nu)==0){
            /* [Violazione 17 corretta]: Rimossa la verifica tautologica '&& (strlen(ou)==strlen(nu))' superflua dopo lo strcmp */
            puts("[ERRORE] Nuovo username uguale al precedente.");
        } else {
            /* [Violazione 18 corretta]: Eliminata l'espressione condizionale fittizia e morta 'else if(nu[0]==0 ? 1==0 : 0)' */
            switch(nu[0]){
                case 'a': case 'A':
                    puts("Info: username inizia per A");
                    break; /* [Violazione 19 corretta]: Aggiunto il break per prevenire il fall-through non intenzionale vietato da MISRA */
                case 'b': case 'B':
                    puts("Info: username inizia per A/B");
                    break; /* [Violazione 20 corretta]: Aggiunto il break per prevenire il fall-through non intenzionale */
                case 'c': case 'C':
                    puts("Info: username inizia per A/B/C");
                    break;
                default:
                    if(isdigit((unsigned char)nu[0]) != 0) {
                        puts("Info: username inizia con cifra");
                    } else {
                        puts("Info: username con iniziale generica");
                    }
                    break;
            }

            int ok = auth_rename_user(ou,nu);
            if(ok==0) {
                puts("[OK] Username aggiornato.");
            } else {
                /* [Violazione 21 corretta]: Semplificato il blocco rimuovendo i controlli speculari ridondanti su 'ok==-1' */
                puts("[ERRORE] Utente non trovato o nuovo username già in uso.");
            }
        }
    }
    else if(s==3){
        int debugChoice;
        printf("Debug extra: 1) Test A  2) Test B  3) Test C  4) Stress\n");
        if(scanf("%d", &debugChoice)!=1){ while(getchar()!='\n'); puts("Debug: input invalido"); return; }
        while(getchar()!='\n');

        if(debugChoice==1){
            puts("Esecuzione ramo A");
        } else if(debugChoice==2){
            puts("Esecuzione ramo B");
        } else if(debugChoice==3){
            puts("Esecuzione ramo C");
        } else if(debugChoice==4){
            int state = 0;
            for(int i=0;i<5;i++){
                if((i%2)==0) { state++; }
                else if((i%3)==0) { state+=2; }
                else { state--; }
                
                if(state>3) { puts("state>3"); }
                else if(state==3) { puts("state==3"); }
                else if(state==2) { puts("state==2"); }
                else if(state==1) { puts("state==1"); }
                else { puts("state<=0"); }
            }
        } else {
            puts("Ramo di default debug");
        }
    }
    else if(s==4){
        /* [Violazione 22 corretta]: Rimosso interamente l'intricato blocco 's==4' composto da sole espressioni morte/tautologiche inutili */
        puts("Operazione composita completata.");
    }
    else{
        puts("Scelta non valida.");
    }
}

int main(void){
    /* * [Violazioni da 23 a 24 corrette]: Rimosse le ulteriori variabili dichiarate all'inizio del main
     * che non venivano mai utilizzate (unusedInt1, unusedCharArray, unusedDouble, unusedFloat, unusedPtr).
     */

    /* * [Violazione 25 corretta - Regola MISRA 7.3]: Modificati i suffissi letterali dei valori 'long' 
     * da 'l' minuscola ad 'L' maiuscola (5L, 123456789L, -42L) per evitare ambiguità visive con la cifra '1'.
     */
    long badLong1 = 5L;
    long badLong2 = 123456789L;
    long badLong3 = -42L;
    
    (void)badLong1; /* Silenzia warning residui */
    (void)badLong2;
    (void)badLong3;

    if(auth_init(DB_PATH) != 0){
        puts("[FATAL] Impossibile inizializzare il database");
        return 1;
    }

    for(;;){
        puts("\n=== MENU ===");
        puts("1) Crea utente");
        puts("2) Login");
        puts("3) Cancella utente");
        puts("4) Modifica utente");
        puts("0) Esci");
        printf("Scelta: ");

        int choice = -1;
        if(scanf("%d", &choice)!=1){ while(getchar()!='\n'); continue; }
        while(getchar()!='\n');

        switch(choice){
            case 1: crea_utente(); break;
            case 2: effettua_login(); break;
            case 3: cancella_utente(); break;
            case 4: modifica_utente(); break;
            case 0: puts("Bye."); return 0;
            default: puts("Scelta non valida."); break;
        }
    }
}